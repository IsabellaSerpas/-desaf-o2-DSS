<?php
require_once __DIR__ . '/../includes/db.php';

class archivos {
    private $conn;

    public function __construct() {
        $this->conn = Database::connect();
    }

    public function saveFile($nombre_archivo, $tipo_archivo, $ruta, $id_project) {
        $stmt = $this->conn->prepare("INSERT INTO files (nombre_archivo, tipo_archivo, ruta, id_project) VALUES (?, ?, ?, ?)");
        return $stmt->execute([$nombre_archivo, $tipo_archivo, $ruta, $id_project]);
    }

    public function deleteFile($id) {
        $stmt = $this->conn->prepare("DELETE FROM files WHERE id = ?");
        return $stmt->execute([$id]);
    }
}
?>
