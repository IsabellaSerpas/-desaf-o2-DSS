
<?php
class Database {
    private static $host = 'localhost';
    private static $db = 'empresa_colab';
    private static $user = 'root';
    private static $pass = '';
    public static function connect() {
        try {
            return new PDO("mysql:host=".self::$host.";dbname=".self::$db, self::$user, self::$pass);
        } catch (PDOException $e) {
            die("Error de conexión: " . $e->getMessage());
        }
    }
}
?>
