<?php
$directorioDestino = "C:/wamp64/www/app/includes/archivero/";

// Subida de archivos
if (isset($_POST['submit'])) {
    $archivoSubido = $directorioDestino . basename($_FILES["archivo"]["name"]);
    $tipoArchivo = strtolower(pathinfo($archivoSubido, PATHINFO_EXTENSION));

    if ($_FILES["archivo"]["size"] > 5000000) {
        echo "El archivo es demasiado grande.<br>";
    } elseif (!in_array($tipoArchivo, ["jpg", "png", "pdf", "docx", "txt"])) {
        echo "Tipo de archivo no permitido.<br>";
    } else {
        if (move_uploaded_file($_FILES["archivo"]["tmp_name"], $archivoSubido)) {
            echo "Archivo subido exitosamente: " . basename($_FILES["archivo"]["name"]) . "<br>";
        } else {
            echo "Error al subir el archivo.<br>";
        }
    }
}

// Eliminación de archivos
if (isset($_POST['eliminar']) && isset($_POST['archivo'])) {
    $archivoEliminar = $directorioDestino . basename($_POST['archivo']);
    if (file_exists($archivoEliminar)) {
        unlink($archivoEliminar);
        echo "Archivo eliminado: " . htmlspecialchars($_POST['archivo']) . "<br>";
    } else {
        echo "El archivo no existe.<br>";
    }
}


// Obtener lista de archivos
$archivos = array_diff(scandir($directorioDestino), ['.', '..']);
?>

<link href="../assets/css/style.css" rel="stylesheet">


<!-- Lista de archivos -->
<div class="container">
<h2>Archivos en el sistema</h2>
<ul>
<?php foreach ($archivos as $archivo): ?>
    <li>
        <?php echo htmlspecialchars($archivo); ?>
        <form action="subir.php" method="post" style="display:inline;">
            <input type="hidden" name="archivo" value="<?php echo htmlspecialchars($archivo); ?>">
            <button type="submit" name="eliminar">Eliminar</button>
        </form>
    </li>
</form>
<?php endforeach; ?>
<br>
<br>
<br>
<form action="..\views\dashboard.php" method="get">
    <button type="submit">Regresar</button>
</ul>
</div>
