
<?php
require_once 'classes/usuario.php';
session_start();

$user = new usuario();

if (isset($_GET['action']) && $_GET['action'] === 'register') {
    if ($user->registro($_POST['nombre'], $_POST['email'], $_POST['password'])) {
        header("Location: views/login.php");
    } else {
        echo "Error al registrar.";
    }
}

if (isset($_GET['action']) && $_GET['action'] === 'login') {
    $usuario = $user->login($_POST['email'], $_POST['password']);
    if ($usuario) {
        $_SESSION['user_id'] = $usuario['id'];
        $_SESSION['user_name'] = $usuario['nombre'];
        header("Location: views/dashboard.php");
    } else {
        echo "Credenciales inválidas.";
    }
}
?>
