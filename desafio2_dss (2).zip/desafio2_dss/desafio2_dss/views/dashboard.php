
<?php require_once '../includes/auth.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <h2>Bienvenido, <?php echo $_SESSION['user_name']; ?>!</h2>
    <form action="../includes/subir.php" method="post" enctype="multipart/form-data">
    <label for="archivo">Selecciona un archivo:</label>
    <input type="file" name="archivo" id="archivo">
    <button type="submit" name="submit">Subir y ver archivo</button>
    </form>
        <p><a href="../logout.php">Cerrar sesión</a></p>
    </div>

</body>
</html>
