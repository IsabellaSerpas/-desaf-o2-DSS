
<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <h2>Iniciar Sesión</h2>
        <form action="../index.php?action=login" method="POST">
            <input type="email" name="email" required placeholder="Correo">
            <input type="password" name="password" required placeholder="Contraseña">
            <button type="submit">Entrar</button>
        </form>
        <a href="registro.php">Registrarse</a>
    </div>
</body>
</html>
