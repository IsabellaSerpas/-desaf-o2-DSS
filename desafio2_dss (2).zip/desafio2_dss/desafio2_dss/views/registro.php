
<!DOCTYPE html>
<html>
<head>
    <title>Registro</title>
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <h2>Registro</h2>
        <form action="../index.php?action=register" method="POST">
            <input type="text" name="nombre" required placeholder="Nombre completo">
            <input type="email" name="email" required placeholder="Correo">
            <input type="password" name="password" required placeholder="Contraseña">
            <button type="submit">Registrar</button>
        </form>
        <a href="login.php">Ya tengo cuenta</a>
    </div>
</body>
</html>
